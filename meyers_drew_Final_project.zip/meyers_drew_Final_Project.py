from tkinter import *
from tkinter import messagebox

root = Tk()

root.geometry("1000x900")

root.title("Welcome to Beatza Hut")

# images and labels
image = PhotoImage(file=r'C:\\Users\A_MEY\\OneDrive\\Documents\\GUI_pictures\\pepperoni.png')

image_2 = PhotoImage(file=r'C:\\Users\A_MEY\\OneDrive\\Documents\\GUI_pictures\\Garlic_Cheese.png')

label1 = Label(text="What kind of pizza would you like")
image_3 = PhotoImage(file=r'C:\\Users\A_MEY\\OneDrive\\Documents\\GUI_pictures\\wheat.gif')
image_4 = PhotoImage(file=r'C:\\Users\A_MEY\\OneDrive\\Documents\\GUI_pictures\\Delievery.png')
canvas_3 = Canvas(root, width=500, height=300)
canvas_3.pack()
canvas_3.create_image(0, 0, anchor=NW, image=image_3)


# new windows





def opennewwindow1():
    newWindow1 = Toplevel()
    newWindow1.title("Pepperoni")
    newWindow1.geometry("800x400")
    exit_button_newWindow = Button(newWindow1, text="Exit", command=newWindow1.destroy).pack()
    label2 = Label(newWindow1, text="This is pepperoni").pack()
    canvas = Canvas(newWindow1, width=300, height=250)
    canvas.pack()
    canvas.create_image(0, 0, anchor=NW, image=image)


def opennewwindow2():
    newWindow2 = Toplevel()
    newWindow2.title("cheese")
    newWindow2.geometry("800x400")
    exit_button_newWindow = Button(newWindow2, text=" select this and exit", command=newWindow2.destroy).pack()
    label3 = Label(newWindow2, text="This is a cheese pizza").pack()
    canvas_2 = Canvas(newWindow2, width=500, height=300)
    canvas_2.pack()
    canvas_2.create_image(0, 0, anchor=NW, image=image_2)


name_Tf = Entry(root)

Label(root, text="Enter Address").pack()

name_Tf.pack()


def location():
    canvas_3.destroy()
    canvas_4 = Canvas(root, width=500, height=500)
    canvas_4.pack()
    canvas_4.create_image(0, 0, anchor=NW, image=image_4)
    return messagebox.showinfo('message', f'Thank you choosing cheese delivering to' + name_Tf.get())

def location_2():
    canvas_3.destroy()
    canvas_4 = Canvas(root, width=500, height=500)
    canvas_4.pack()
    canvas_4.create_image(0, 0, anchor=NW, image=image_4)
    return messagebox.showinfo('message', f'Thank you choosing Pepperoni delivering to ' + name_Tf.get())



confirm_button = Button(root, text="Cheese is final order", command=location).pack()
confirm_button_2 = Button(root, text="Pepperoni final order", command=location_2).pack()
# Button area
cheese_button = Button(root, text="Cheese", command=opennewwindow2)
pepperoni_button = Button(root, text="Pepperoni", command=opennewwindow1)

exit_button = Button(root, text="Exit", command=root.destroy)

# packaging center
exit_button.pack()

pepperoni_button.pack(padx=5, pady=10, side=RIGHT)
cheese_button.pack(side=LEFT)
label1.pack(padx=10, pady=10)

root.mainloop()
